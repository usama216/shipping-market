<?php

/**
 * Check Latest DHL Error Log - Production Version
 * 
 * Run via browser:
 * https://marketsz.com/check_dhl_error_production.php
 */

// Determine the correct storage path
// If running from public directory, go up one level
$basePath = __DIR__;
if (strpos($basePath, '/public') !== false || strpos($basePath, '\\public') !== false) {
    $basePath = dirname($basePath);
}

// Try multiple possible paths
$possiblePaths = [
    $basePath . '/storage/logs',
    dirname($basePath) . '/storage/logs',
    '/home5/miro777/public_html/storage/logs',
    __DIR__ . '/../storage/logs',
];

$logPath = null;
foreach ($possiblePaths as $path) {
    if (is_dir($path)) {
        $logPath = $path;
        break;
    }
}

// Try to bootstrap Laravel to use storage_path() if available
if (!$logPath && file_exists($basePath . '/bootstrap/app.php')) {
    try {
        require_once $basePath . '/vendor/autoload.php';
        $app = require_once $basePath . '/bootstrap/app.php';
        $app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();
        $logPath = storage_path('logs');
    } catch (\Exception $e) {
        // Laravel bootstrap failed, use calculated path
    }
}

if (!$logPath) {
    $logPath = $basePath . '/storage/logs'; // Default fallback
}

echo "=== Checking DHL Error Logs ===\n\n";
echo "Base path: {$basePath}\n";
echo "Looking in: {$logPath}\n";
echo "Path exists: " . (is_dir($logPath) ? 'Yes ✓' : 'No ✗') . "\n\n";

// Check for error JSON files
$errorFiles = glob($logPath . '/dhl-error-*.json');

if (empty($errorFiles)) {
    echo "❌ No DHL error log files found.\n";
    echo "   Path: {$logPath}\n\n";
    
    // Check Laravel log instead
    $laravelLog = $logPath . '/laravel.log';
    $carrierLog = $logPath . '/carrier.log';
    
    echo "Checking Laravel log: {$laravelLog}\n";
    echo "File exists: " . (file_exists($laravelLog) ? 'Yes ✓' : 'No ✗') . "\n";
    echo "Checking Carrier log: {$carrierLog}\n";
    echo "File exists: " . (file_exists($carrierLog) ? 'Yes ✓' : 'No ✗') . "\n\n";
    
    if (file_exists($laravelLog)) {
        echo "📋 Checking Laravel log for DHL errors...\n\n";
        
        $logContent = file_get_contents($laravelLog);
        
        // Search for DHL error entries
        if (preg_match_all('/DHL API Error.*?\{.*?\}/s', $logContent, $matches)) {
            echo "Found " . count($matches[0]) . " DHL error entries in Laravel log:\n\n";
            foreach ($matches[0] as $index => $match) {
                echo "=== Error Entry #" . ($index + 1) . " ===\n";
                // Try to extract JSON from the log entry
                if (preg_match('/\{.*\}/s', $match, $jsonMatch)) {
                    $json = json_decode($jsonMatch[0], true);
                    if ($json) {
                        echo "Status: " . ($json['status'] ?? 'N/A') . "\n";
                        if (isset($json['full_body_string'])) {
                            echo "Full Body Length: " . strlen($json['full_body_string']) . "\n";
                            echo "\nFull Body String (first 2000 chars):\n";
                            echo substr($json['full_body_string'], 0, 2000) . "\n";
                            
                            // Try to parse it
                            $parsed = json_decode($json['full_body_string'], true);
                            if ($parsed && isset($parsed['additionalDetails'])) {
                                echo "\n✅ Found additionalDetails in parsed body!\n";
                                echo "Count: " . count($parsed['additionalDetails']) . "\n\n";
                                foreach ($parsed['additionalDetails'] as $i => $detail) {
                                    echo "Error #" . ($i + 1) . ":\n";
                                    echo "  Field: " . ($detail['field'] ?? 'N/A') . "\n";
                                    echo "  Message: " . ($detail['message'] ?? $detail['invalidValue'] ?? 'N/A') . "\n";
                                    if (isset($detail['value'])) {
                                        echo "  Value: " . $detail['value'] . "\n";
                                    }
                                    echo "\n";
                                }
                            }
                        }
                    }
                }
                echo "\n";
            }
        } else {
            echo "⚠️  No DHL error entries found in Laravel log.\n";
        }
    }
    
    // Also check carrier.log
    if (file_exists($carrierLog)) {
        echo "\n📋 Checking Carrier log for DHL errors...\n\n";
        
        $carrierLogContent = file_get_contents($carrierLog);
        
        // Search for DHL error entries
        if (preg_match_all('/DHL API Error.*?\{.*?\}/s', $carrierLogContent, $matches)) {
            echo "Found " . count($matches[0]) . " DHL error entries in Carrier log:\n\n";
            foreach ($matches[0] as $index => $match) {
                echo "=== Error Entry #" . ($index + 1) . " ===\n";
                // Try to extract JSON from the log entry
                if (preg_match('/\{.*\}/s', $match, $jsonMatch)) {
                    $json = json_decode($jsonMatch[0], true);
                    if ($json && isset($json['full_body_string'])) {
                        echo "Full Body Length: " . strlen($json['full_body_string']) . "\n";
                        echo "\nFull Body String (first 2000 chars):\n";
                        echo substr($json['full_body_string'], 0, 2000) . "\n";
                        
                        // Try to parse it
                        $parsed = json_decode($json['full_body_string'], true);
                        if ($parsed && isset($parsed['additionalDetails'])) {
                            echo "\n✅ Found additionalDetails in parsed body!\n";
                            echo "Count: " . count($parsed['additionalDetails']) . "\n\n";
                            foreach ($parsed['additionalDetails'] as $i => $detail) {
                                echo "Error #" . ($i + 1) . ":\n";
                                echo "  Field: " . ($detail['field'] ?? 'N/A') . "\n";
                                echo "  Message: " . ($detail['message'] ?? $detail['invalidValue'] ?? 'N/A') . "\n";
                                if (isset($detail['value'])) {
                                    echo "  Value: " . $detail['value'] . "\n";
                                }
                                echo "\n";
                            }
                        }
                    }
                }
                echo "\n";
            }
        } else {
            echo "⚠️  No DHL error entries found in Carrier log.\n";
        }
    }
    
    echo "\n\n=== Directory Listing ===\n";
    if (is_dir($logPath)) {
        $files = scandir($logPath);
        echo "Files in {$logPath}:\n";
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $filePath = $logPath . '/' . $file;
                $size = is_file($filePath) ? filesize($filePath) : 0;
                $modified = is_file($filePath) ? date('Y-m-d H:i:s', filemtime($filePath)) : 'N/A';
                echo "  - {$file} (" . number_format($size) . " bytes, modified: {$modified})\n";
            }
        }
    } else {
        echo "❌ Log directory does not exist: {$logPath}\n";
        echo "\nTried these paths:\n";
        foreach ($possiblePaths as $path) {
            echo "  - {$path} " . (is_dir($path) ? '✓' : '✗') . "\n";
        }
    }
    
    exit(1);
}

// Get the most recent error file
usort($errorFiles, function($a, $b) {
    return filemtime($b) - filemtime($a);
});

$latestFile = $errorFiles[0];
echo "✓ Found latest error log: " . basename($latestFile) . "\n";
echo "   Full path: {$latestFile}\n";
echo "   Modified: " . date('Y-m-d H:i:s', filemtime($latestFile)) . "\n\n";

$errorData = json_decode(file_get_contents($latestFile), true);

if (!$errorData) {
    echo "❌ Could not parse error log file.\n";
    exit(1);
}

echo "=== Error Summary ===\n";
echo "Status Code: " . ($errorData['status'] ?? 'N/A') . "\n";
echo "Endpoint: " . ($errorData['endpoint'] ?? 'N/A') . "\n";
echo "Method: " . ($errorData['method'] ?? 'N/A') . "\n\n";

if (isset($errorData['response_json'])) {
    $response = $errorData['response_json'];
    
    echo "=== DHL Error Response ===\n";
    echo "Title: " . ($response['title'] ?? 'N/A') . "\n";
    echo "Detail: " . ($response['detail'] ?? 'N/A') . "\n";
    echo "Instance: " . ($response['instance'] ?? 'N/A') . "\n\n";
    
    if (isset($response['additionalDetails']) && is_array($response['additionalDetails'])) {
        echo "=== Validation Errors ===\n";
        foreach ($response['additionalDetails'] as $index => $detail) {
            echo "\nError #" . ($index + 1) . ":\n";
            echo "  Field: " . ($detail['field'] ?? 'N/A') . "\n";
            echo "  Message: " . ($detail['message'] ?? 'N/A') . "\n";
            if (isset($detail['value'])) {
                echo "  Value: " . $detail['value'] . "\n";
            }
            if (isset($detail['invalidValue'])) {
                echo "  Invalid Value: " . $detail['invalidValue'] . "\n";
            }
        }
    } else {
        echo "⚠️  No validation errors found in additionalDetails\n";
        echo "   Response keys: " . implode(', ', array_keys($response)) . "\n";
        
        // Try parsing raw body
        if (isset($errorData['response_body_raw'])) {
            echo "\n📋 Trying to parse raw response body...\n";
            $parsed = json_decode($errorData['response_body_raw'], true);
            if ($parsed && isset($parsed['additionalDetails'])) {
                echo "✅ Found additionalDetails in raw body!\n";
                foreach ($parsed['additionalDetails'] as $index => $detail) {
                    echo "\nError #" . ($index + 1) . ":\n";
                    echo "  Field: " . ($detail['field'] ?? 'N/A') . "\n";
                    echo "  Message: " . ($detail['message'] ?? $detail['invalidValue'] ?? 'N/A') . "\n";
                }
            } else {
                echo "❌ Could not parse raw body or no additionalDetails found.\n";
                echo "   Raw body (first 500 chars): " . substr($errorData['response_body_raw'], 0, 500) . "\n";
            }
        }
    }
}

if (isset($errorData['validation_errors']) && !empty($errorData['validation_errors'])) {
    echo "\n=== Extracted Validation Errors ===\n";
    foreach ($errorData['validation_errors'] as $index => $error) {
        echo "\nError #" . ($index + 1) . ":\n";
        if (is_array($error)) {
            echo "  Field: " . ($error['field'] ?? 'N/A') . "\n";
            echo "  Message: " . ($error['message'] ?? 'N/A') . "\n";
        } else {
            echo "  Error: " . $error . "\n";
        }
    }
}

echo "\n\n=== Full Error Log (JSON) ===\n";
echo json_encode($errorData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

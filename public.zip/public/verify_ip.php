<?php

/**
 * Server IP Verification Script for MyUS API Whitelisting
 * 
 * Run this on your production server to get the exact IP address
 * that needs to be whitelisted by MyUS.
 * 
 * Usage on server:
 *   php verify_server_ip.php
 *   OR access via browser: https://yourdomain.com/verify_server_ip.php
 */

// Set headers for browser access
if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain; charset=UTF-8');
}

echo "🌐 Server IP Verification for MyUS API Whitelisting\n";
echo str_repeat("=", 80) . "\n\n";

// Server Information
echo "📋 Server Information\n";
echo str_repeat("-", 80) . "\n";

$serverInfo = [
    'Server Name' => $_SERVER['SERVER_NAME'] ?? 'N/A',
    'HTTP Host' => $_SERVER['HTTP_HOST'] ?? 'N/A',
    'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'N/A',
    'PHP Version' => PHP_VERSION,
];

foreach ($serverInfo as $key => $value) {
    echo sprintf("   %-20s: %s\n", $key, $value);
}
echo "\n";

// IP Address Detection
echo "🔍 IP Address Detection\n";
echo str_repeat("-", 80) . "\n";

$ips = [];

// Method 1: Server Address (internal)
if (!empty($_SERVER['SERVER_ADDR'])) {
    $ips['Server Address (Internal)'] = $_SERVER['SERVER_ADDR'];
}

// Method 2: Remote Address (if accessed via browser)
if (!empty($_SERVER['REMOTE_ADDR'])) {
    $ips['Remote Address'] = $_SERVER['REMOTE_ADDR'];
}

// Method 3: HTTP Headers (if behind proxy/load balancer)
$headerIPs = [];
$headerKeys = [
    'HTTP_X_FORWARDED_FOR',
    'HTTP_X_REAL_IP',
    'HTTP_CF_CONNECTING_IP', // Cloudflare
    'HTTP_X_FORWARDED',
    'HTTP_CLIENT_IP',
];

foreach ($headerKeys as $key) {
    if (!empty($_SERVER[$key])) {
        $headerIPs[$key] = $_SERVER[$key];
    }
}

if (!empty($headerIPs)) {
    echo "   ⚠️  Detected Proxy/Load Balancer Headers:\n";
    foreach ($headerIPs as $key => $value) {
        echo "      {$key}: {$value}\n";
    }
    echo "\n";
}

// Method 4: Public IP via External Services
echo "   Fetching Public IP from external services...\n";

$publicIpServices = [
    'https://api.ipify.org' => 'ipify.org',
    'https://ifconfig.me' => 'ifconfig.me',
    'https://ipinfo.io/ip' => 'ipinfo.io',
    'https://icanhazip.com' => 'icanhazip.com',
    'https://checkip.amazonaws.com' => 'AWS',
];

$publicIPs = [];
foreach ($publicIpServices as $url => $service) {
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => 5,
                'method' => 'GET',
            ]
        ]);
        
        $ip = @file_get_contents($url, false, $context);
        if ($ip && filter_var(trim($ip), FILTER_VALIDATE_IP)) {
            $cleanIP = trim($ip);
            $publicIPs[$service] = $cleanIP;
            echo "      ✅ {$service}: {$cleanIP}\n";
        }
    } catch (Exception $e) {
        echo "      ❌ {$service}: Failed\n";
    }
}

echo "\n";

// Determine Primary IP
echo "📊 IP Address Summary\n";
echo str_repeat("-", 80) . "\n";

if (!empty($ips)) {
    foreach ($ips as $label => $ip) {
        echo sprintf("   %-30s: %s\n", $label, $ip);
    }
}

if (!empty($publicIPs)) {
    // Get most common IP (if multiple services agree)
    $ipCounts = array_count_values($publicIPs);
    arsort($ipCounts);
    $primaryIP = array_key_first($ipCounts);
    $count = $ipCounts[$primaryIP];
    
    echo "\n   🌟 PRIMARY PUBLIC IP (for MyUS whitelisting):\n";
    echo "      {$primaryIP}\n";
    
    if ($count > 1) {
        echo "      (Confirmed by {$count} services)\n";
    }
    
    if (count($publicIPs) > 1 && count(array_unique($publicIPs)) > 1) {
        echo "\n   ⚠️  WARNING: Multiple different IPs detected!\n";
        echo "      This might indicate:\n";
        echo "      - Multiple network interfaces\n";
        echo "      - Load balancer/proxy configuration\n";
        echo "      - CDN in front of server\n";
        echo "\n   All detected IPs:\n";
        foreach (array_unique($publicIPs) as $ip) {
            echo "      - {$ip}\n";
        }
    }
} else {
    echo "   ❌ Could not determine public IP from external services\n";
    echo "   Check your server's network configuration manually\n";
}

echo "\n";

// MyUS Configuration Check
echo "🔐 MyUS Configuration Check\n";
echo str_repeat("-", 80) . "\n";

try {
    if (file_exists(__DIR__ . '/.env')) {
        $envContent = file_get_contents(__DIR__ . '/.env');
        
        $myusConfig = [
            'MYUS_BASE_URL' => preg_match('/MYUS_BASE_URL=(.+)/', $envContent, $m) ? trim($m[1]) : 'Not found',
            'MYUS_AFFILIATE_ID' => preg_match('/MYUS_AFFILIATE_ID=(.+)/', $envContent, $m) ? trim($m[1]) : 'Not found',
            'MYUS_MEMBER_ID' => preg_match('/MYUS_MEMBER_ID=(.+)/', $envContent, $m) ? trim($m[1]) : 'Not found',
            'MYUS_SUITE' => preg_match('/MYUS_SUITE=(.+)/', $envContent, $m) ? trim($m[1]) : 'Not found',
        ];
        
        foreach ($myusConfig as $key => $value) {
            if ($value !== 'Not found') {
                echo sprintf("   %-25s: %s\n", $key, $value);
            } else {
                echo sprintf("   %-25s: ❌ Not configured\n", $key);
            }
        }
    } else {
        echo "   ⚠️  .env file not found\n";
    }
} catch (Exception $e) {
    echo "   ⚠️  Could not read configuration: " . $e->getMessage() . "\n";
}

echo "\n";

// Whitelisting Instructions
echo "📝 MyUS Whitelisting Instructions\n";
echo str_repeat("=", 80) . "\n\n";

if (!empty($primaryIP)) {
    echo "1. Contact MyUS Support with the following information:\n\n";
    echo "   Subject: API Access - IP Whitelisting Required\n\n";
    echo "   Hello MyUS Support,\n\n";
    echo "   I need API access from my production server. Please whitelist:\n\n";
    echo "   Server IP Address: {$primaryIP}\n";
    
    if (!empty($serverInfo['HTTP Host'])) {
        echo "   Domain: {$serverInfo['HTTP Host']}\n";
    }
    
    if (!empty($myusConfig['MYUS_AFFILIATE_ID']) && $myusConfig['MYUS_AFFILIATE_ID'] !== 'Not found') {
        echo "   Affiliate ID: {$myusConfig['MYUS_AFFILIATE_ID']}\n";
    }
    
    if (!empty($myusConfig['MYUS_MEMBER_ID']) && $myusConfig['MYUS_MEMBER_ID'] !== 'Not found') {
        echo "   Member ID: {$myusConfig['MYUS_MEMBER_ID']}\n";
    }
    
    if (!empty($myusConfig['MYUS_SUITE']) && $myusConfig['MYUS_SUITE'] !== 'Not found') {
        echo "   Suite: {$myusConfig['MYUS_SUITE']}\n";
    }
    
    echo "\n   Currently getting 403 Access Denied on all API endpoints.\n";
    echo "   Please:\n";
    echo "   1. Whitelist IP: {$primaryIP}\n";
    echo "   2. Verify my Bearer token is valid\n";
    echo "   3. Provide correct API endpoint URLs for:\n";
    echo "      - Package retrieval\n";
    echo "      - Shipment retrieval\n";
    echo "      - Any other relevant endpoints\n\n";
    echo "   Thank you!\n\n";
    
    echo "2. After whitelisting, test the connection:\n";
    echo "   php test_myus_server.php\n\n";
    
    echo "3. If you have multiple IPs, you may need to whitelist all of them.\n";
} else {
    echo "⚠️  Could not determine server IP. Please:\n";
    echo "   1. Check your server's network configuration\n";
    echo "   2. Contact your hosting provider for the public IP\n";
    echo "   3. Run this script again after fixing network issues\n";
}

echo "\n";
echo str_repeat("=", 80) . "\n";
echo "✅ Verification complete!\n";

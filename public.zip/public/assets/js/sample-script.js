// Check if GSAP is loaded (scripts at bottom of body, so DOM is ready)
if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
  console.error('GSAP or ScrollTrigger not loaded. Make sure GSAP scripts are loaded before this script.');
} else {
  gsap.registerPlugin(ScrollTrigger);

  // Hassle free section animations

  const hfCurve1Path = document.getElementById("hf-curve-1-path");
  const hfCurve2Path = document.getElementById("hf-curve-2-path");
  const hfCurve3Path = document.getElementById("hf-curve-3-path");

  // Only proceed if curve paths exist
  if (!hfCurve1Path || !hfCurve2Path || !hfCurve3Path) {
    console.warn('Hassle-free curve paths not found, skipping those animations');
  } else {
    const hfSectionTimeline = gsap.timeline({
      repeat: 0,
      defaults: {
        ease: "bounce",
        duration: 1,
        transformOrigin: "50% 100%",
        opacity: 0,
        scale: 0.2,
      },
    });

    const hfp1PathLength = hfCurve1Path.getTotalLength();
    const hfp2PathLength = hfCurve2Path.getTotalLength();
    const hfp3PathLength = hfCurve3Path.getTotalLength();

    hfCurve1Path.style.strokeDashoffset = hfp1PathLength;
    hfCurve2Path.style.strokeDashoffset = hfp2PathLength;
    hfCurve3Path.style.strokeDashoffset = hfp3PathLength;

    hfCurve1Path.style.strokeDasharray = hfp1PathLength;
    hfCurve2Path.style.strokeDasharray = hfp2PathLength;
    hfCurve3Path.style.strokeDasharray = hfp3PathLength;

    const curveAnimationDefaults = {
      scale: 1,
      opacity: 1,
      ease: "linear",
      strokeDashoffset: 0,
    };

    hfSectionTimeline
      .from(".hf-destination-card-1", {})
      .to(hfCurve1Path, {
        ...curveAnimationDefaults,
        duration: 0.5,
      })
      .from(".hf-destination-card-2", {})
      .to(hfCurve2Path, {
        ...curveAnimationDefaults,
        duration: 2,
      })
      .from(".hf-warehouse-icon", {}, "<=1.7")
      .from(
        ".hf-cargo-track-container",
        {
          x: "200",
        },
        "<=0.8"
      )
      .from(
        ".hf-destination-card-3",
        {
          transformOrigin: "100% 50%",
        },
        "<=0.2"
      )
      .to(hfCurve3Path, {
        ...curveAnimationDefaults,
        duration: 2,
      })
      .from(".hf-destination-card-4", {}, "<=1.6")
      .from(".hf-learn-more-btn", {});

    const triggerElement = document.querySelector(".hf-destination-card-2");
    if (triggerElement) {
      ScrollTrigger.create({
        trigger: triggerElement,
        start: "top center",
        animation: hfSectionTimeline,
      });
    }
  }

  // All other animations that use DOM elements
  gsap.from(".hassle-free-animated-cart", {
  scrollTrigger: ".hassle-free-animated-cart",
  x: -500,
  duration: 1.5,
  ease: "bounce",
});
gsap.from(".mbl-hassle-free-animated-cart", {
  scrollTrigger: ".mbl-hassle-free-animated-cart",
  x: -500,
  duration: 1.5,
  ease: "bounce",
});

// end - Hassle free section animations

gsap.from(".animated-cart-animation-2", {
  scrollTrigger: ".animated-cart-animation-2",
  x: -500,
  duration: 1.5,
  ease: "bounce",
});

gsap.from(".su-aeroplane", {
  scrollTrigger: ".su-aeroplane",
  x: -300,
  duration: 2,
  ease: "power1.out",
});

gsap.from(".su-boxes", {
  scrollTrigger: ".su-boxes",
  x: -300,
  rotate: -360,
  scale: 0.01,
  duration: 1,
  ease: "power2.out",
});

// HF Blue Badge animations start
const blueBadgePopTimeline = gsap.timeline({
  repeat: 0,
  repeatDelay: 0,
  defaults: {
    ease: "bounce",
    duration: 1,
  },
});

gsap.to(".hassle-free-blue-badge", {
  scrollTrigger: ".hassle-free-blue-badge-4",
  scale: 1,
  ease: "bounce",
  duration: 1,
});
gsap.to(".mbl-hassle-free-blue-badge", {
  scrollTrigger: ".mbl-hassle-free-blue-badge-4",
  scale: 1,
  ease: "bounce",
  duration: 1,
});
gsap.to(".hassle-free-blue-badge", {
  scrollTrigger: ".hassle-free-blue-badge-4",
  scale: 1,
  ease: "bounce",
  duration: 1,
});

const blueBadgeSwingTimeline = gsap.timeline({
  repeat: -1,
  repeatDelay: 0,
  defaults: {
    ease: "linear",
    duration: 1,
  },
});

const CU_DEG = 2;

blueBadgeSwingTimeline
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    rotate: CU_DEG,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    rotate: -CU_DEG,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    rotate: -1 * CU_DEG,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    rotate: 0,
  });

const BB_Y = 10;
const blueBadgeFloatTimeline = gsap.timeline({
  repeat: -1,
  repeatDelay: 0,
  defaults: {
    ease: "linear",
    duration: 1,
  },
});

blueBadgeFloatTimeline
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    y: "+=" + BB_Y,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    y: "-=" + BB_Y,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    y: "+=" + BB_Y,
  })
  .to([".hassle-free-blue-badge", ".mbl-hassle-free-blue-badge"], {
    y: "-=" + BB_Y,
  });
// HF Blue Badge animations end

// fork lift animation starts here!
const forkliftTimeline = gsap.timeline({
  repeat: -1,
  repeatDelay: 1,
  defaults: {
    ease: "linear",
    duration: 10,
  },
});

// Responsive logic

const handleResizeWindow = () => {
  const vw = window.innerWidth;

  const imgWidth = vw < 1100 ? 120 : 210;

  forkliftTimeline
    .to(".forklift-machine-img", {
      left: `calc(95vw - ${imgWidth}px)`,
    })
    .to(".forklift-machine-img", {
      duration: 1,
      left: `calc(95vw - ${imgWidth}px)`,
    })
    .to(".forklift-machine-img", {
      duration: 0.01,
      scaleX: -1,
    })
    .to(".forklift-machine-img", {
      left: "5vw",
    });
};

handleResizeWindow();

window.addEventListener("resize", handleResizeWindow);

const fl_floatTimeline = gsap.timeline({
  repeat: -1,
  repeatDelay: 0,
  defaults: {
    ease: "linear",
    duration: 0.1,
  },
});

fl_floatTimeline
  .to(".forklift-machine-img", {
    y: "+=2",
  })
  .to(".forklift-machine-img", {
    y: "0",
  });

// fork lift animation ends here!
gsap
  .timeline({ repeat: -1, ease: "linear", repeatDelay: 0 })
  .to(".rotating-box", { duration: 1, rotate: 20 })
  .to(".rotating-box", { duration: 1, rotate: -20 });

gsap
  .timeline({ repeat: -1, ease: "none", repeatDelay: 0 })
  .to(".rotating-circle", { duration: 10, rotate: 360 });

gsap
  .timeline({ repeat: -1 })
  .to(".tts-box", { duration: 5, y: 250 })
  .to(".tts-box", { duration: 1, y: 0 });

gsap
  .timeline({ repeat: -1, ease: "linear", repeatDelay: 0 })
  .to(".rotating-aeroplane", { duration: 1, rotate: 10 })
  .to(".rotating-aeroplane", { duration: 1, rotate: -10 });

// CLOUD_ANIMATION_TIMES = CAT
const CAT = [72, 48, 24];

gsap
  .timeline({ repeat: -1, ease: "none", repeatDelay: 0 })
  .to(".hero-cloud-1", { duration: CAT[0], x: '500%' })
  .to(".hero-cloud-1", { duration: CAT[0], x: 0 })
  .to(".hero-cloud-2", { duration: CAT[0], x: '600%' })
  .to(".hero-cloud-2", { duration: CAT[0], x: 0 });

gsap
  .timeline({ repeat: -1, ease: "none", repeatDelay: 0 })
  .to(".hero-cloud-4", { duration: CAT[1], x: '-600%' })
  .to(".hero-cloud-4", { duration: CAT[1], x: 0 })
  .to(".hero-cloud-5", { duration: CAT[1], x: '-500%' })
  .to(".hero-cloud-5", { duration: CAT[1], x: 0 });

gsap
  .timeline({ repeat: -1, ease: "none", repeatDelay: 0 })
  .to(".hero-cloud-3", { duration: CAT[2], x: '400%' })
  .to(".hero-cloud-3", { duration: CAT[2], x: '-400%' })
  .to(".hero-cloud-3", { duration: CAT[2], x: 0 })

gsap
  .timeline({ repeat: -1, ease: "linear", repeatDelay: 0 })
  .to(".hero-black-crow", { duration: 1.5, y: 5, scaleX: 0.2, scaleY: 0.8 })
  .to(".hero-black-crow", { duration: 1.5, y: 0, scaleX: 1, scaleY: 1 });

  const heroAeroPlane = document.querySelector(".hero-aeroplane");
  const heroAeroPlane2 = document.querySelector(".hero-aeroplane-2");
  const box = document.querySelector(".hero-box");

  if (heroAeroPlane2 && box) {
    gsap.set([heroAeroPlane2, box], { autoAlpha: 0 });
  }

  // Only create hero animations if elements exist
  if (heroAeroPlane && heroAeroPlane2 && box) {
    const masterTimeline = gsap.timeline({
      repeat: -1,
      repeatDelay: 0,
    });

    // HPHS = Home Page Hero Section
    const HPHS_PLANE_DURATION = 8;
    const HPHS_PACKAGE_DURATION = 3;
    const HPHS_PACKAGE_Y = "+=150";

    masterTimeline
      .to(heroAeroPlane, {
    duration: HPHS_PLANE_DURATION,
    ease: "power3.inOut",
    scale: 1.7,
    motionPath: {
      path: ".path",
      align: ".path",
      alignOrigin: [0.5, 0.5],
      autoRotate: true,
      start: 0,
      end: 0.5,
      onReverseComplete: () => {
        gsap.set(heroAeroPlane2, { autoAlpha: 0 });
      },
    },
    onStart: () => {
      gsap.to(heroAeroPlane, { autoAlpha: 1, duration: 0 });
    },
  })
  .to(box, {
    duration: 0,
    ease: "none",
    scale: 0.2,
    motionPath: {
      path: ".path",
      align: ".path",
      alignOrigin: [0.5, -0.5],
      autoRotate: false,
      start: 0.5, // Start at the end of the previous animation
      end: 0.5,
    },
    onComplete: () => {
      gsap.to(box, { autoAlpha: 1, duration: 0 });
    },
  })
  .to(box, {
    duration: HPHS_PACKAGE_DURATION,
    y: HPHS_PACKAGE_Y, // Translate down by 150px
    scale: 1,
    onComplete: () => {
      gsap.to([heroAeroPlane, box], { autoAlpha: 0, duration: 0 });
    },
  })
  .to(heroAeroPlane2, {
    duration: HPHS_PLANE_DURATION,
    ease: "power3.inOut",
    scale: 1.7,
    motionPath: {
      path: ".path",
      align: ".path",
      alignOrigin: [0.5, 0.5],
      autoRotate: true,
      start: 1,
      end: 0.5,
    },
    onStart: () => {
      gsap.to(heroAeroPlane2, { autoAlpha: 1, duration: 0 });
    },
    onComplete: () => {
      gsap.to(box, { autoAlpha: 1, duration: 0 });
    },
  })
  .to(box, {
    duration: 0,
    ease: "none",
    opacity: 0,
    scale: 0.2,
    motionPath: {
      path: ".path",
      align: ".path",
      alignOrigin: [0.5, -0.5],
      autoRotate: false,
      start: 0.5, // Start at the end of the previous animation
      end: 0.5,
    },
    onComplete: () => {
      gsap.to(box, { autoAlpha: 1, duration: 0 });
    },
  })
  .to(box, {
    duration: HPHS_PACKAGE_DURATION,
    y: HPHS_PACKAGE_Y, // Translate down by 150px
    scale: 1,
    onComplete: () => {
      gsap.to([heroAeroPlane2, box], { autoAlpha: 0, duration: 0 });
    },
  });

    // Only use GSDevTools if available (usually for development)
    if (typeof GSDevTools !== 'undefined') {
      GSDevTools.create({ animation: masterTimeline });
    }
  }
};  // End of GSAP check

// /////////////////////////      Time To Shop /////////////////////////

// gsap.timeline({ repeat: -1 })
// .to(".tts-box", { duration: 5, y: 300 })
// .to(".tts-box", { duration: 1, y: 0, rotate: 0 });

// ////////////////////        /////////////////////////

